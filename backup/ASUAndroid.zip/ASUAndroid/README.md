# ASUAndroid
ASU Application for Army Military Members

Try this:
```
1.) Install Android Studio
2.) Enable SVM in BIOS
3.) Enable Hypervisor for windows 10
4.) In android Studio:   VCS> Get from version Control > Login to your github account and add the URL and clone
```

If you are going to add new feature, this is how you start:
```
You should never be making any changes to code while you are on master branch
1.) Select Git --> Master branch
2.) VCS -> Git -> Pull
3.) Create a new branch
4.) Add new feature
```
